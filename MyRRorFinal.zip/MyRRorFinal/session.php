<?php
//Start session
session_start();


if (!isset($_SESSION['username']) || (trim($_SESSION['username']) == '')) {
    header("location:login.php");
    exit();
}

if (!isset($_SESSION['id']) || (trim($_SESSION['id']) == '')) {
    header("location:login.php");
    exit();
}



?>
