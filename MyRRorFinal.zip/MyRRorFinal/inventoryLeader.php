<?php
include 'include/controller.php';
$session_username = $_SESSION['username'];
$session_idu = $_SESSION['id'];
$session_squad = $_SESSION['Squadra'];
$install="0";
if(empty($_SESSION['username'])){
    header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Pannello TeamLeader</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="js/jquery-1.12.4.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-theme.min.css">
    <link rel="stylesheet" href="css/loader.css">
    <link rel="stylesheet" href="./css/style2.css">

    <link rel="stylesheet" type="text/css" href="dashboard/vendor/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="css/responsive.bootstrap.min.css">
    <script>
        $(document).ready(function() {
                $('#example').DataTable({});
            });

        </script>



    <script type="text/javascript">

    $(document).on('hidden.bs.modal', function (e) {
           var target = $(e.target);
           target.removeData('bs.modal')

       });
    </script>
</head>

<body onload="myFunction()" style="margin:0;">
  <div class="move">  <img class="img-responsive" src="logo.jpg" alt="some text" width="130" height="80" style="  position: relative;

    left: 40%;

    top: 50%"> <img src="LOGOed.jpg" alt="some text" width="130" height="80" style="  position: relative;

      left: 40%;

      top: 50%"></div>
    <div class="tesss">
  <div class="smth">

    <div class="container">

        <div class="dropdown">
            <button class="btn btn-danger dropdown-toggle btn-md" type="button" data-toggle="dropdown" style="font-size:20px"><span class='glyphicon glyphicon-user' aria-hidden='true'></span>
                <?php echo $session_username ; ?> <span class="caret"></span></button>
            <ul class="dropdown-menu">
                <li ><a href="#logout" data-toggle="modal" style="font-size:20px"><span class='glyphicon glyphicon-log-out' aria-hidden='true' style="font-size:20px"></span>Disconnettersi</a></li>
              <!--  <li><a href="#changepass" data-toggle="modal"><span class='glyphicon glyphicon-edit' aria-hidden='true'></span> Change Password</a></li>-->
            </ul>
              <!--
            <a href="#add" data-toggle="modal">
                <button type='button' class='btn btn-success btn-sm'><span class='glyphicon glyphicon-plus' aria-hidden='true'></span> Job</button>
            </a>
          -->
        </div>
        <br>
        <table id="example" class="display nowrap" cellspacing="0" width="100%">
            <thead>
                <tr>

                    <th style="font-size:20px">Tipo di Lavoro</th>
                    <th style="font-size:19px">Priority</th>
                    <th style="font-size:19px">WR</th>
                    <th style="font-size:19px">Data</th>
                    <th style="font-size:19px">Ora</th>
                    <th style="font-size:19px">Centrale</th>
                    <th style="font-size:19px">Risorsa</th>
                    <th style="font-size:19px"></th>

                </tr>
            </thead>


            <tbody>
                <?php
                    $sql = "SELECT *  FROM job_pk1 WHERE Squadra='$session_squad' AND stato_lavorazione='6' ";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        // output data of each row
                        while($row = $result->fetch_assoc()) {
                            $id= $row['ID'];
                            $intervento= $row['intervento'];
                            $nome= $row['Nome_Cliente'];
                            $risorsa = $row['risorsa'];
                            $dataapp = $row['data_appuntamento'];
                            $oraap = $row['Ora_Appto'];
                            $wr = $row['WR'];
                            $centrale = $row['centrale'];
                            $note = $row['Note'];
                            $slav= $row['stato_lavorazione'];
                            $indirizzo=$row['Indirizzo_Cliente'];
                            $tcentrale=$row['Tipo_centrale'];
                            $squadra=$row['Squadra'];
                            $sistema=$row['System'];
                            $descri=$row['Descrizione'];
                            $operator=$row['Operatore'];
                            $priority=$row['Priority'];
                            $sasse=$row['seconda_assegnazione'];
                            $f1r=$row['F1R'];
                            $assegna=$row['Assegnazione'];
                            $retel=$row['recapito_tel_cliente'];

                    ?>
                <tr>

                    <td style="font-size:19px">
                        <?php echo $intervento; ?>
                    </td>
                    <td style="font-size:19px">
                        <?php echo $priority; ?>
                    </td>

                    <td style="font-size:19px">
                        <?php echo $wr; ?>
                    </td>
                    <td style="font-size:19px">
                        <?php echo $dataapp; ?>
                    </td>
                    <td style="font-size:19px">
                        <?php echo $oraap; ?>
                    </td>
                    <td style="font-size:19px">
                        <?php echo $centrale; ?>
                    </td>
                    <td style="font-size:19px">
                        <?php echo $risorsa; ?>
                    </td>


                    <td>

                        <a href="#edit<?php echo $id;?>" data-toggle="modal">
                            <button type='button' class='btn btn-warning btn-lg' style="font-size:20px" ><span class='glyphicon glyphicon-zoom-in' aria-hidden='true'style="font-size:20px" ></span></button>
                        </a>
                        <a href="#change<?php echo $id;?>" data-toggle="modal">
                            <button type='button' class='btn btn-info btn-lg' style="font-size:20px" ><span class='glyphicon glyphicon-transfer' aria-hidden='true'style="font-size:20px" ></span></button>
                        </a>



                    </td>


                <!--
                  <div id="changepass" class="modal fade" role="dialog">
                        <div class="modal-dialog">

                            <div class="modal-content">
                                <form action="" method="post">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <h4 class="modal-title">Change Password</h4>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label class="control-label col-sm-2" for="name">Current:</label>
                                            <div class="col-sm-10">
                                                <input type="password" class="form-control" name="current_password" required placeholder="Current Password" autofocus autocomplete="off"> </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-2" for="name">New:</label>
                                            <div class="col-sm-10">
                                                <input type="password" class="form-control" name="new_password" required placeholder="New Password" autocomplete="off"> </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-2" for="name">Repeat:</label>
                                            <div class="col-sm-10">
                                                <input type="password" class="form-control" name="repeat_password" required placeholder="Repeat Password" autocomplete="off"> </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-primary" name="change_pass">Update</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>


                 -->


                    <!--Edit Item Modal -->
                    <div id="edit<?php echo $id; ?>" class="modal fade" role="dialog">
                        <form method="post" class="form-horizontal" role="form">
                            <div class="modal-dialog modal-lg">
                                <!-- Modal content-->
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <h2 class="modal-title">Dettagli lavoro</h2>
                                    </div>
                                    <div class="modal-body">
                                                <input type="hidden" name="edit_item_id" value="<?php echo $id; ?>">
                                                <div class="form-group">
                                                  <label class="control-label col-sm-2" for="descri" style="font-size:20px">Descrizione:</label>
                                                  <div class="col-sm-4">
                                                      <textarea  class="form-control" id="descri" name="descri"  placeholder="Descrizione"  rows="20"   style="font-size:20px" readonly><?php echo $descri; ?></textarea> </div>
                                                      <label class="control-label col-sm-2" for="nclie" style="font-size:20px"> Cliente:</label>
                                                      <div class="col-sm-4">
                                                          <input type="text" class="form-control" id="nclie" name="nclie" value="<?php echo $nome; ?>" placeholder="Nome"  readonly style="font-size:20px"> </div>


                                                </div>
                                                <div class="form-group">
                                                  <label class="control-label col-sm-2" for="centrale" style="font-size:20px">Centrale:</label>
                                                  <div class="col-sm-4">
                                                      <input type="text"  class="form-control" id="centrale" name="centrale" value="<?php echo $centrale; ?>" placeholder="Centrale"  readonly style="font-size:20px"> </div>
                                                      <label class="control-label col-sm-2" for="idel" style="font-size:20px">Indirizzo:</label>
                                                      <div class="col-sm-4">
                                                          <textarea class="form-control" id="idel" name="idel"  placeholder="Indirizzo"  rows="4" readonly style="font-size:20px"><?php echo $indirizzo; ?></textarea> </div>
                                                    </div>

        										<div class="form-group">
                              <label class="control-label col-sm-2" for="squadra" style="font-size:20px">Squadra:</label>
                              <div class="col-sm-4">
                                  <input type="text" class="form-control" id="squadra" name="squadra" value="<?php echo $squadra; ?>"  placeholder="Squadra"  readonly style="font-size:20px"> </div>

                                                    <label class="control-label col-sm-2" for="sistema" style="font-size:20px">Sistema:</label>
                                                    <div class="col-sm-4">
                                                        <input type="text" class="form-control" id="sistema" name="sistema" value="<?php echo $sistema; ?>" placeholder="Sistema" readonly style="font-size:20px"> </div>
                                                </div>
        										<div class="form-group">
                              <label class="control-label col-sm-2" for="risorsa" style="font-size:20px">Risorsa:</label>
                              <div class="col-sm-4">
                                  <input type="text"  class="form-control" id="risorsa" name="risorsa" value="<?php echo $risorsa; ?>" placeholder="Risorsa" readonly  style="font-size:20px"> </div>

                                                    <label class="control-label col-sm-2" for="operator" style="font-size:20px">Operatore:</label>
                                                    <div class="col-sm-4">
                                                        <input type="text" class="form-control" id="operator" name="operator" value="<?php echo $operator; ?>" placeholder="Operatore"  readonly style="font-size:20px"> </div>
                                                        <label class="control-label col-sm-2" for="telc" style="font-size:20px">TelCliente:</label>
                                                        <div class="col-sm-4">
                                                            <input type="text" class="form-control" id="telc" name="telc" value="<?php echo $retel; ?>" placeholder="TelCliente"  readonly style="font-size:20px"> </div>


                                                        <label class="control-label col-sm-2" for="note" style="font-size:20px">Note:</label>
                                                        <div class="col-sm-4">
                                                            <input type="text" class="form-control" id="note" name="note" value="<?php echo $note; ?>" placeholder="Note"  readonly style="font-size:20px"> </div>


                                                                <label class="control-label col-sm-2" for="secass" style="font-size:20px">Assegn2:</label>
                                                                <div class="col-sm-4">
                                                                    <input type="text" class="form-control" id="secass" name="secass" value="<?php echo $sasse; ?>" placeholder="SecondaAssegnazione"  readonly style="font-size:20px"> </div>

                                                                    <label class="control-label col-sm-2" for="f1r" style="font-size:20px">F1R:</label>
                                                                    <div class="col-sm-4">
                                                                        <input type="text" class="form-control" id="f1r" name="f1r" value="<?php echo $f1r; ?>" placeholder="F1R"  readonly style="font-size:20px"> </div>



                                                </div>



                                            </div>
                                    <div class="modal-footer">
                                  <!--    <button type="submit" class="btn btn-warning" name="update_item"><span class="glyphicon glyphicon-edit"></span> Salva</button>-->
                                        <button type="button" class="btn btn-danger btn-lg" data-dismiss="modal" style="font-size:20px" ><span class="glyphicon glyphicon-remove-circle" style="font-size:20px" ></span> Chiudi</button>
                                        <!--    <button type="submit" class="btn btn-danger" name="closepk1"><span class="glyphicon glyphicon-off"></span> Chiudi chiamata</button>-->
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>






                    <!--Tecnic Edit Modal -->
                    <div id="tecnicedit<?php echo $id; ?>" class="modal fade" role="dialog">
                        <form method="post" class="form-horizontal" role="form">
                            <div class="modal-dialog modal-lg">
                                <!-- Modal content-->
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <h2 class="modal-title">Chiudi Lavoro</h2>
                                    </div>
                                    <div class="modal-body">
                                                <input type="hidden" name="tecnicid" value="<?php echo $id; ?>">
                                                <div class="form-group">
                                                    <label class="control-label col-sm-2" for="comm" style="font-size:20px ">Commento:</label>
                                                    <div class="col-sm-4">
                                                        <textarea  class="form-control" id="comm" name="comm"  placeholder="Commento"  rows="20"  style="font-size:20px"></textarea> </div>
                                                    <label class="control-label col-sm-2" for="modem" style="font-size:20px">Modem:</label>
                                                    <div class="col-sm-4">
                                                        <input type="checkbox"  class="form-control" id="modem" name="modem"  placeholder="Modem"  style="font-size:20px" > </div>
                                                </div>
                                                <div class="form-group">
</div>
<div class="form-group">
</div>
                                                <div class="form-group">
                                                  <label class="control-label col-sm-2" for="mtype" style="font-size:20px">TipoModem:</label>
                                                  <div class="col-sm-4">
                                                    <select class="form-control" name="mtype" id="mtype" style="font-size:20px">
                        <option selected="true" disabled="disabled">Selezionare</option>

                      <option value="Belkin">Belkin</option>
                      <option value="TP-LINK">TP-LINK</option>
                      <option value="3COM">3COM</option>
                      <option value="ZyXEL">ZyXEL</option>
                      <option value="Fibra">Fibra</option>
                      </select>

                                                    </div>
                                                    </div>


                            <div class="form-group">
                              <label class="control-label col-sm-2" for="conf" style="font-size:20px">Conf:</label>
                              <div class="col-sm-4">
                            <input type="number" max="5"  class="form-control" id="conf" name="conf"  placeholder="Conf" style="font-size:20px" >
                            </div>
                            <label class="control-label col-sm-2" for="ctype" style="font-size:20px">CondType:</label>
                            <div class="col-sm-4">
                              <select class="form-control" name="ctype" id="ctype" style="font-size:20px">
  <option selected="true" disabled="disabled">Selezionare</option>

<option value="Cordoncino">Cordoncino</option>
<option value="Cavetto">Cavetto</option>
<option value="Bronzo">Bronzo</option>
<option value="Pura">Pura</option>
</select> </div>
                                <label class="control-label col-sm-2" for="metres" style="font-size:20px">Metres:</label>
                                <div class="col-sm-4">
                                    <input type="number"  class="form-control" id="metres" name="metres"  placeholder="Metres" style="font-size:20px" > </div>



                                                </div>



                                            </div>

                                    <div class="modal-footer">
                                   <button type="submit" class="btn btn-info btn-lg" name="update_item" style="font-size:20px" ><span class="glyphicon glyphicon-edit" style="font-size:20px" ></span> Chiudi</button>
                                   <button type="submit" class="btn btn-danger btn-lg" name="allert_item" style="font-size:20px" ><span class="glyphicon glyphicon-warning-sign" style="font-size:20px" ></span> Allert</button>
                              <button type="button" class="btn btn-warning btn-lg" data-dismiss="modal" onclick="window.location.reload();"  style="font-size:20px" ><span class="glyphicon glyphicon-remove-circle" style="font-size:20px" ></span> Annulla</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>


                    <!--riapp Item Modal -->
                    <div id="riapp<?php echo $id; ?>" class="modal fade" role="dialog">
                        <form method="post" class="form-horizontal" role="form">
                            <div class="modal-dialog modal-lg">
                                <!-- Modal content-->
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <h2 class="modal-title">Da Riappuntamentare</h2>
                                    </div>
                                    <div class="modal-body">
                              <input type="hidden" name="riappid" value="<?php echo $id; ?>">
                            <div class="form-group">
                              <label class="control-label col-sm-2" for="note" style="font-size:20px">Commento:</label>
                              <div class="col-sm-4">
                                <textarea  class="form-control" id="note" name="note"  placeholder="Commento"  rows="20"  required="required" style="font-size:20px"></textarea> </div>
                                                </div>


                                            </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary btn-lg" name="salriap" style="font-size:20px" ><span class="glyphicon glyphicon-edit" style="font-size:20px" ></span> Salva</button>
                                        <button type="button" class="btn btn-success btn-lg" data-dismiss="modal"  style="font-size:20px" ><span class="glyphicon glyphicon-remove-circle" style="font-size:20px" ></span> Annulla</button>

                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>




                    <!--Change job Modal -->
                    <div id="change<?php echo $id; ?>" class="modal fade" role="dialog">
                        <form method="post" class="form-horizontal" role="form">
                            <div class="modal-dialog modal-lg">
                                <!-- Modal content-->
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <h2 class="modal-title">Cambia Tecnico</h2>
                                    </div>
                                    <div class="modal-body">
                              <input type="hidden" name="changeid" value="<?php echo $id; ?>">
                            <div class="form-group">
                              <label class="control-label col-sm-2" for="tecid" style="font-size:20px">TecnicoID:</label>
                              <div class="col-sm-4">
                            <input type="text"   class="form-control" id="tecid" name="tecid"  value="<?php echo $assegna; ?>"  placeholder="TecnicoID" style="font-size:20px" readonly >
                            </div>
                            <label class="control-label col-sm-2" for="ntecid" style="font-size:20px">NuovoID:</label>
                            <div class="col-sm-4">
                          <input type="number"   class="form-control" id="ntecid" name="ntecid"  placeholder="AssegnaTecnico" style="font-size:20px">
                          </div>
                                                </div>





                                            </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary btn-lg" name="changej" style="font-size:20px" ><span class="glyphicon glyphicon-edit" style="font-size:20px" ></span> Salva</button>
                                        <button type="button" class="btn btn-success btn-lg" data-dismiss="modal"  style="font-size:20px" ><span class="glyphicon glyphicon-remove-circle" style="font-size:20px" ></span> Annulla</button>

                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>















                                        <!--Delivery Modal -->
                                        <div id="delivery<?php echo $id; ?>" class="modal fade" role="dialog">
                                            <form method="post" class="form-horizontal" role="form">
                                                <div class="modal-dialog modal-lg">
                                                    <!-- Modal content-->
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                            <h2 class="modal-title">DELIVERY</h2>
                                                              <h3 class="modal-title">DELIVERY OK</h3>
                                                        </div>
                                                        <div class="modal-body">
                                                                    <input type="hidden" name="deliveryid" value="<?php echo $id; ?>">

                                                                    <div class="form-group">
                                                                        <label class="control-label col-sm-2" for="valo" style="font-size:18px">Valori:</label>
                                                                        <div class="col-sm-4">
                                                                            <input type="number" class="form-control" id="valo" name="valo"  placeholder="Valori" style="font-size:20px"> </div>
                                                                        <label class="control-label col-sm-2" for="1pr" style="font-size:18px">1 Presa:</label>
                                                                        <div class="col-sm-4">
                                                                            <input type="text"  class="form-control" id="1pr" name="1pr"  placeholder="1 Presa"style="font-size:20px" > </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                      <label class="control-label col-sm-2" for="notedel" style="font-size:18px">Note:</label>
                                                                      <div class="col-sm-4">
                                                                          <input type="text"  class="form-control" id="notedel" name="notedel"  placeholder="Note" style="font-size:20px" > </div>
                                                                          </div>




                                                                </div>
                                                        <div class="modal-footer">
                                                   <button type="submit" class="btn btn-success" name="updatedeliveryok" style="font-size:20px" ><span class="glyphicon glyphicon-edit" style="font-size:20px" ></span> Salva</button>
                                                   <button type="submit" class="btn btn-primary" name="allert" style="font-size:20px" ><span class="glyphicon glyphicon-ok-circle" style="font-size:20px" ></span> DELIVERY KO</button>
                                                            <button type="button" class="btn btn-danger" data-dismiss="modal" style="font-size:20px"  ><span class="glyphicon glyphicon-remove-circle" style="font-size:20px" ></span> Annulla</button>

                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>












                    <!--Delete Modal
                    <div id="delete<?php echo $id; ?>" class="modal fade" role="dialog">
                        <div class="modal-dialog">
                            <form method="post">

                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <h4 class="modal-title">Delete</h4>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="delete_id" value="<?php echo $id; ?>">
                                        <div class="alert alert-danger">Are you Sure you want Delete <strong>
                                                <?php echo $serial; ?>?</strong> </div>
                                        <div class="modal-footer">
                                            <button type="submit" name="delete" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> YES</button>
                                            <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove-circle"></span> NO</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    -->
                </tr>
                <?php
                        }
                    /*    if(isset($_POST['change_pass'])){
                            $sql = "SELECT password FROM users WHERE username='$session_username'";
                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                                // output data of each row
                                while($row = $result->fetch_assoc()) {
                                    if($row['password'] != $current_password){
                                        echo "<script>window.alert('Invalid Password');</script>";
                                        $passwordErr = '<div class="alert alert-warning"><strong>Password!</strong> Invalid.</div>';
                                    } elseif($new_password != $repeat_password) {
                                        echo "<script>window.alert('Password Not Match!');</script>";
                                        $passwordErr = '<div class="alert alert-warning"><strong>Password!</strong> Not Match.</div>';
                                    } else{
                                        $sql = "UPDATE users SET password='$new_password' WHERE username='$session_username'";

                                        if ($conn->query($sql) === TRUE) {
                                            echo "<script>window.alert('Password Successfully Updated');</script>";
                                        } else {
                                            echo "Error updating record: " . $conn->error;
                                        }
                                    }
                                }
                            } else {
                                $usernameErr = '<div class="alert alert-danger"><strong>Username</strong> Not Found.</div>';
                                $username = "";
                            }
                        }

                      */
                        //Update Items
                        if(isset($_POST['update_item'])){
                          $tecnicid = $_POST['tecnicid'];
                          $comm=$_POST['comm'];
                              $mtype=$_POST['mtype'];
                              $conf=$_POST['conf'];
                              $ctype=$_POST['ctype'];
                              $metres=$_POST['metres'];
                              if(isset($_POST['modem'])) {
                   $modem=true;}
                   else{
                      $modem=false;
                   }

                              $slav=3;
                            $sql = "UPDATE Referto_PK2 SET
                                commento='$comm',
                                Modem='$modem',
                                MTYPE='$mtype',
                                Conf='$conf',
                                CondType='$ctype',
                                Metres='$metres'
                                WHERE job='$tecnicid' ";
                            if ($conn->query($sql) === TRUE) {
                                echo '<script>window.location.href="inventoryLeader.php"</script>';
                            } else {
                                echo "Error updating record: " . $conn->error;
                            }

                            $sql2 = "UPDATE job_PK1 SET
                                stato_lavorazione='$slav'
                                WHERE ID='$tecnicid' ";
                            if ($conn->query($sql2) === TRUE) {
                                echo '<script>window.location.href="inventoryLeader.php"</script>';
                            } else {
                                echo "Error updating record: " . $conn->error;
                            }
                        }








                        //Allert Items
                        if(isset($_POST['allert_item'])){
                          $tecnicid = $_POST['tecnicid'];

                            $allert=true;

                              $slav=3;
                            $sql = "UPDATE Referto_PK2 SET
                                Allert='$allert'
                                WHERE job='$tecnicid' ";
                            if ($conn->query($sql) === TRUE) {
                                echo '<script>window.location.href="inventoryLeader.php"</script>';
                            } else {
                                echo "Error updating record: " . $conn->error;
                            }


                        }


                        //Change Technic
                        if(isset($_POST['changej'])){
                          $tecnicid = $_POST['changeid'];

                              $ntecid=$_POST['ntecid'];


                            $sql = "UPDATE job_pk1 SET
                                Assegnazione='$ntecid'
                                WHERE ID='$tecnicid' ";
                            if ($conn->query($sql) === TRUE) {
                                echo '<script>window.location.href="inventoryLeader.php"</script>';
                            } else {
                                echo "Error updating record: " . $conn->error;
                            }


                        }





                        //Update deliveryok
                        if(isset($_POST['updatedeliveryok'])){
                          $deliveryid = $_POST['deliveryid'];
                              $valo=$_POST['valo'];
                              $pr1=$_POST['1pr'];
                              $notedel=$_POST['notedel'];
                              $slav=3;
                            $sql = "UPDATE Referto_PK2 SET
                            Valori='$valo',
                                commento='$notedel',
                                1presa='$pr1'
                                WHERE job='$deliveryid' ";
                            if ($conn->query($sql) === TRUE) {
                                echo '<script>window.location.href="inventoryLeader.php"</script>';
                            } else {
                                echo "Error updating record: " . $conn->error;
                            }

                            $sql2 = "UPDATE job_PK1 SET
                                stato_lavorazione='$slav'
                                WHERE ID='$deliveryid' ";
                            if ($conn->query($sql2) === TRUE) {
                                echo '<script>window.location.href="inventoryLeader.php"</script>';
                            } else {
                                echo "Error updating record: " . $conn->error;
                            }

                        }


                        //Update allert
                        if(isset($_POST['allert'])){
                          $deliveryid = $_POST['deliveryid'];
                              $valo=true;
                              $slav=3;
                            $sql = "UPDATE Referto_PK2 SET
                            Allert='$valo'
                                WHERE job='$deliveryid' ";
                            if ($conn->query($sql) === TRUE) {
                                echo '<script>window.location.href="inventoryLeader.php"</script>';
                            } else {
                                echo "Error updating record: " . $conn->error;
                            }

                          $sql2 = "UPDATE job_PK1 SET
                                stato_lavorazione='$slav'
                                WHERE ID='$deliveryid' ";
                            if ($conn->query($sql2) === TRUE) {
                                echo '<script>window.location.href="inventoryLeader.php"</script>';
                            } else {
                                echo "Error updating record: " . $conn->error;
                            }

                        }






                        //Update PDR PK2 Items
                        if(isset($_POST['update_item2'])){
                          $pdrpk2id = $_POST['pdrpk2id'];
                              $col=$_POST['col'];
                              $copp=$_POST['copp'];
                              $Arm=$_POST['arm'];
                                $Arm1=$_POST['arm1'];
                                  $Arm2=$_POST['arm2'];
                                    $SDX=$_POST['sdx'];
                                    $SottoArm2=$_POST['sottoarm2'];
                                    $Box=$_POST['box'];
                              $slav=3;

                               $sql1="SELECT pdr FROM Referto_PK2 WHERE job='$pdrpk2id' ";
                              $result = $conn->query($sql1);
                              if ($result->num_rows > 0) {
                                  // output data of each row
                                  while($row = $result->fetch_assoc()) {
                                    $pdrid=$row['pdr'];
                                  }
                                }
                                else {
                                   echo "Error selecting record1: " . $conn->error;
                               }


                            $sql = "UPDATE PDR_PK2 SET
                                COLONNA='$col',
                                COPPIA='$copp',
                                ARMADIO='$Arm',
                                COPPIA_PRIMARIA='$Arm1',
                                COPPIA_SECONDARIA='$Arm2',
                                 SOTTOARMADIO='$SDX',
                                COPPIA_SECONDARIA_SOTTOARMADIO='$SottoArm2',
                                BOX='$Box'
                                WHERE ID='$pdrid' ";
                            if ($conn->query($sql) === TRUE) {
                              $sql = "UPDATE job_PK1 SET
                                  stato_lavorazione='$slav'
                                  WHERE ID='$pdrpk2id' ";
                              if ($conn->query($sql) === TRUE) {
                                  echo '<script>window.location.href="inventory.php"</script>';
                              } else {
                                  echo "Error updating record: " . $conn->error;
                              }
                            } else {
                                echo "Error updating record: " . $conn->error;
                            }


                        }





                        //riappuntamento
                        if(isset($_POST['salriap'])){
                          $riappid = $_POST['riappid'];
                          $note =  $_POST['note'];
                          $slav=7;
                          $sql = "UPDATE Referto_PK2 SET
                              commento='$note'
                              WHERE job='$riappid' ";
                          if ($conn->query($sql) === TRUE) {
                              echo '<script>window.location.href="inventoryLeader.php"</script>';
                          } else {
                              echo "Error updating record: " . $conn->error;
                          }

                          $sql2 = "UPDATE job_PK1 SET
                              stato_lavorazione='$slav'
                              WHERE ID='$riappid' ";
                          if ($conn->query($sql2) === TRUE) {
                              echo '<script>window.location.href="inventoryLeader.php"</script>';
                          } else {
                              echo "Error updating record: " . $conn->error;
                          }


                        }




                        //chiuso
                        if(isset($_POST['closepk1'])){
                          $edit_item_id = $_POST['edit_item_id'];
                          $slav=3;


                          $sql = "UPDATE job_PK1 SET
                              stato_lavorazione='$slav'
                              WHERE ID='$edit_item_id' ";
                          if ($conn->query($sql) === TRUE) {
                              echo '<script>window.location.href="inventoryLeader.php"</script>';
                          } else {
                              echo "Error updating record: " . $conn->error;
                          }

                        }








                        if(isset($_POST['delete'])){
                            // sql to delete a record
                            $delete_id = $_POST['delete_id'];
                            $sql = "DELETE FROM services WHERE id='$delete_id' ";
                            if ($conn->query($sql) === TRUE) {
                                $sql = "DELETE FROM services WHERE id='$delete_id' ";
                                if ($conn->query($sql) === TRUE) {
                                    $sql = "DELETE FROM services WHERE id='$delete_id' ";
                                    echo '<script>window.location.href="inventory.php"</script>';
                                } else {
                                    echo "Error deleting record: " . $conn->error;
                                }
                            } else {
                                echo "Error deleting record: " . $conn->error;
                            }
                        }
                    }

                    //Add Item
                    if(isset($_POST['add_job'])){
                        $seriale = $_POST['seriale'];
                        $mac = $_POST['mac'];
                        $modello = $_POST['modello'];
                        $dingresso=$_POST['dingresso'];
                        $du = $_POST['du'];
                        $servicef = $_POST['servicef'];
                        if(isset($_POST['tecnico'])) {
                       $tecnico="1";}
                       else{
                          $tecnico="0";
                       }
                        if(isset($_POST['installato'])) {
	                     $installato="1";}
                       else{
                          $installato="0";
                       }
                        $odl = $_POST['odl'];
                        $di = $_POST['di'];
                        $nome = $_POST['nome'];
                        $codice = $_POST['codice'];
                        $qta = $_POST['qta'];
                        $contatore = $_POST['contatore'];
                        $codice128 = $_POST['codice128'];
                        $sql = "INSERT INTO services (serial,macaddress,model,dataingreso,exitdate,service ,tecnic,installed,odl,installationdate,tecnicname,codice,qta,contatore,codice128)VALUES ('$seriale','$mac','$modello','$dingresso','$du','$servicef','$tecnico','$installato','$odl','$di','$nome','$codice','$qta','$contatore','$codice128')";
                        if ($conn->query($sql) === TRUE) {

                            echo '<script>window.location.href="inventory.php"</script>';
                        } else {
                            echo "Error: " . $sql . "<br>" . $conn->error;
                        }
                    }
?>
            </tbody>
        </table>
    </div>
  </div>
    <!--Add Item Modal
    <div id="add" class="modal fade" role="dialog">
        <div class="modal-dialog modal-lg">

            <div class="modal-content">
                <form method="post" class="form-horizontal" role="form">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title"></h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="seriale">Seriale:</label>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" id="seriale" name="seriale" placeholder="Seriale" > </div>
                            <label class="control-label col-sm-2" for="mac">MAC:</label>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" id="mac" name="mac" placeholder="MAC" > </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="modello">Modello:</label>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" id="modello" name="modello" placeholder="Modello" > </div>
                            <label class="control-label col-sm-2" for="dingresso">Data Ingresso:</label>
                            <div class="col-sm-4">
                                <input type="date" class="form-control" id="dingresso" name="dingresso" placeholder="Data Ingresso" > </div>
                                <label class="control-label col-sm-2" for="du">Data Uscita:</label>
                                <div class="col-sm-4">
                                    <input type="date" class="form-control" id="du" name="du" placeholder="Data" > </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="servicef">Service Fortuna:</label>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" id="servicef" name="servicef" placeholder="Service" > </div>
                            <label class="control-label col-sm-2" for="tecnico">Tecnico</label>
                            <div class="col-sm-1">
                                <input type="checkbox" class="form-control" id="tecnico" name="tecnico" placeholder="Tecnico" > </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="installato">Installato</label>
                            <div class="col-sm-1">
                                <input type="checkbox" class="form-control" id="installato" name="installato" > </div>
                            <label class="control-label col-sm-5" for="odl">ODL:</label>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" id="odl" name="odl" placeholder="ODL" > </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="di">Data Installazione:</label>
                            <div class="col-sm-4">
                                <input type="date" class="form-control" id="di" name="di" > </div>
                            <label class="control-label col-sm-2" for="nome">Nome Tecnico:</label>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" id="nome" name="nome" value="<?php echo $session_username; ?>" placeholder="Nome Tecnico"> </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="codice">Codice:</label>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" id="codice" name="codice" placeholder="Codice"> </div>
                                <label class="control-label col-sm-2" for="qta">QTA:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" id="qta" name="qta" placeholder="QTA"> </div>


                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="contatore">Contatore:</label>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" id="contatore" name="contatore" placeholder="Contatore"> </div>
                                <label class="control-label col-sm-2" for="codice128">Codice128:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" id="codice128" name="codice128" placeholder="Codice128"> </div>


                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary" name="add_job"><span class="glyphicon glyphicon-plus"></span> Add</button>
                        <button type="button" class="btn btn-warning" data-dismiss="modal"><span class="glyphicon glyphicon-remove-circle"></span> Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    -->

    <!--Logout Modal -->
    <div id="logout" class="modal fade" role="dialog">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h3 class="modal-title">Disconnettersi</h3>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="delete_id" value="<?php echo $id; ?>" style="font-size:20px">
                    <div class="alert alert-danger" style="font-size:20px">Sei sicuro di voler uscire
                        <strong>
                            <?php echo $_SESSION['username']; ?>?
                        </strong>
                    </div>
                    <div class="modal-footer">
                        <a href="logout.php">
                            <button type="button" class="btn btn-danger btn-lg" style="font-size:20px">SI </button>
                        </a>
                        <button type="button" class="btn btn-default btn-lg" data-dismiss="modal" style="font-size:20px">No</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
</body>

</html>
